// Log.cpp
#include "Log.h"

#include <algorithm>
#include <cctype>

int Log::s_globalLevel = Log::WARNING;

LogLevel::LogLevel(const std::string& name)
    : m_value(Log::stringToLevel(name)) {
}

LogLevel level(const std::string& name) {
    return LogLevel(name);
}

Log::Log()
    : m_messageLevel(WARNING), m_enabled(true) {
    updateEnabled();
}

void Log::set_level(const std::string& name) {
    s_globalLevel = stringToLevel(name);
    updateEnabled();
}

Log& Log::operator<<(const LogLevel& lv) {
    m_messageLevel = lv.m_value;
    updateEnabled();
    return *this;
}

Log& Log::operator<<(std::ostream& (*manip)(std::ostream&)) {
    if (m_enabled) {
        manip(std::cout);
    }

    // In this simple logger, an ostream manipulator such as std::endl
    // is treated as the end of one log message.
    resetMessageLevel();
    return *this;
}

Log& Log::operator<<(std::ios& (*manip)(std::ios&)) {
    if (m_enabled) {
        manip(std::cout);
    }
    return *this;
}

Log& Log::operator<<(std::ios_base& (*manip)(std::ios_base&)) {
    if (m_enabled) {
        manip(std::cout);
    }
    return *this;
}

int Log::stringToLevel(const std::string& name) {
    std::string s = name;
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });

    if (s == "fatal") {
        return FATAL;
    }
    if (s == "error") {
        return ERROR;
    }

    // Unknown levels are treated as warning to keep the class easy to use.
    return WARNING;
}

void Log::updateEnabled() {
    m_enabled = (m_messageLevel >= s_globalLevel);
}

void Log::resetMessageLevel() {
    m_messageLevel = WARNING;
    updateEnabled();
}
