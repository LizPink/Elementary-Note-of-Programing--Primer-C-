// Log.h
#ifndef LOG_H
#define LOG_H

#include <iostream>
#include <string>

// LogLevel is a small helper class used by level("warning"),
// level("error") and level("fatal").
class LogLevel {
public:
    explicit LogLevel(const std::string& name);

private:
    int m_value;

    friend class Log;
};

// Helper function used like: obj << level("fatal") << "BROKEN" << endl;
LogLevel level(const std::string& name);

class Log {
public:
    Log();

    // Set the global lowest output level. Messages whose level is lower
    // than this value will not be printed.
    void set_level(const std::string& name);

    // Receive a message level from level("...").
    Log& operator<<(const LogLevel& lv);

    // Generic stream output operator. It allows usages such as:
    // obj << "message" << 123 << std::endl;
    template <typename T>
    Log& operator<<(const T& value) {
        if (m_enabled) {
            std::cout << value;
        }
        return *this;
    }

    // Support manipulators such as std::endl, std::flush and std::ends.
    Log& operator<<(std::ostream& (*manip)(std::ostream&));

    // Support manipulators such as std::hex, std::dec and std::boolalpha.
    Log& operator<<(std::ios& (*manip)(std::ios&));
    Log& operator<<(std::ios_base& (*manip)(std::ios_base&));

private:
    enum Severity {
        WARNING = 1,
        ERROR = 2,
        FATAL = 3
    };

    static int s_globalLevel;  // shared by all Log objects
    int m_messageLevel;        // level of the current message
    bool m_enabled;            // whether the current message can be printed

    friend class LogLevel;

    static int stringToLevel(const std::string& name);
    void updateEnabled();
    void resetMessageLevel();
};

#endif
