// main.cpp
#include "Log.h"

#include <iostream>

using namespace std;

int main() {
    Log obj;

    // Basic stream-like output.
    obj << "debug message" << endl;

    // Only messages whose level is error or fatal can be printed now.
    obj.set_level("error");

    // warning is lower than error, so this line will not be printed.
    obj << level("warning") << "WARNING MESSAGE" << endl;

    // fatal is higher than error, so this line will be printed.
    obj << level("fatal") << "BROKEN" << endl;

    return 0;
}
