// ScoreSegmentCounter.cpp
#include "ScoreSegmentCounter.h"

#include <stdexcept>

ScoreSegmentCounter::ScoreSegmentCounter(const int scores[], int n)
{
    counts.fill(0);

    for (int i = 0; i < n; ++i)
    {
        int score = scores[i];

        // This problem counts the segments 1-10, 11-20, ..., 91-100.
        // Scores outside 1..100 are ignored.
        if (score >= 1 && score <= 100)
        {
            int segment = (score - 1) / 10;
            ++counts[segment];
        }
    }
}

int ScoreSegmentCounter::operator[](int k) const
{
    if (k < 0 || k >= 10)
    {
        throw std::out_of_range("segment index must be from 0 to 9");
    }

    return counts[k];
}
