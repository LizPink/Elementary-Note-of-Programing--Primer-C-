// main.cpp
#include "ScoreSegmentCounter.h"

#include <iostream>

int main()
{
    int scores[] = {100, 97, 93, 88, 76, 75, 61, 60, 59, 45, 31, 20, 10, 1, 0};
    int n = sizeof(scores) / sizeof(scores[0]);

    ScoreSegmentCounter obj(scores, n);

    for (int k = 0; k < 10; ++k)
    {
        int left = 10 * k + 1;
        int right = 10 * k + 10;
        std::cout << left << "-" << right << ": " << obj[k] << std::endl;
    }

    return 0;
}
