// ScoreSegmentCounter.h
#ifndef SCORE_SEGMENT_COUNTER_H
#define SCORE_SEGMENT_COUNTER_H

#include <array>

// ScoreSegmentCounter counts how many scores fall into each 10-point segment.
// Segment k means: 10 * k + 1 <= score <= 10 * k + 10, where k is 0..9.
class ScoreSegmentCounter
{
public:
    // Initialize the object with an integer score array and its element count.
    ScoreSegmentCounter(const int scores[], int n);

    // Return the number of scores in segment k.
    // Valid k values are 0..9.
    int operator[](int k) const;

private:
    std::array<int, 10> counts; // counts[k] stores the number of scores in segment k.
};

#endif
