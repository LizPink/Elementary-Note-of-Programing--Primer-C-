// IntArrayDescSorter.cpp
#include "IntArrayDescSorter.h"
#include <algorithm>
#include <functional>

void IntArrayDescSorter::operator()(int array[], int n) const
{
    // If the pointer is null or the array has 0 or 1 element,
    // no sorting is necessary.
    if (array == nullptr || n <= 1)
    {
        return;
    }

    // Sort array[0] to array[n - 1] from large to small.
    std::sort(array, array + n, std::greater<int>());
}
