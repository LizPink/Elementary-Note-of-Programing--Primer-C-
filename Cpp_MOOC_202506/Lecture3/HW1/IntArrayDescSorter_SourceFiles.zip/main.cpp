// main.cpp
#include <iostream>
#include "IntArrayDescSorter.h"

int main()
{
    int array[] = {5, 1, 9, 3, 7, 2};
    int N = sizeof(array) / sizeof(array[0]);

    IntArrayDescSorter obj;
    obj(array, N);   // Equivalent to obj.operator()(array, N)

    for (int i = 0; i < N; ++i)
    {
        std::cout << array[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
