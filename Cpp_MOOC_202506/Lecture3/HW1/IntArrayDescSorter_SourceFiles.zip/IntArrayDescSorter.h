// IntArrayDescSorter.h
#ifndef INT_ARRAY_DESC_SORTER_H
#define INT_ARRAY_DESC_SORTER_H

class IntArrayDescSorter
{
public:
    // Overload the function call operator.
    // Usage: sorter(array, n);
    // It sorts the first n elements of array in descending order.
    void operator()(int array[], int n) const;
};

#endif // INT_ARRAY_DESC_SORTER_H
